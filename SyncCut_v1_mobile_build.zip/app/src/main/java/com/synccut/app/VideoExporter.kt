package com.synccut.app

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import java.nio.ByteBuffer
import kotlin.math.max

/**
 * Replace the camera audio with an AAC track from a separate recording.
 * The compressed video packets are copied as-is: no video re-encoding.
 * Positive offset means audio was recorded before the camera video began.
 */
object VideoExporter {
    fun export(context: Context, videoUri: Uri, audioUri: Uri, outputUri: Uri, offsetSeconds: Double) {
        val video = MediaExtractor()
        val audio = MediaExtractor()
        var muxer: MediaMuxer? = null
        var started = false
        try {
            video.setDataSource(context, videoUri, null)
            audio.setDataSource(context, audioUri, null)
            val vIndex = (0 until video.trackCount).firstOrNull {
                video.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true
            } ?: error("لم يتم العثور على مسار فيديو")
            val aIndex = (0 until audio.trackCount).firstOrNull {
                audio.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: error("لم يتم العثور على مسار صوت")
            val vFormat = video.getTrackFormat(vIndex)
            val aFormat = audio.getTrackFormat(aIndex)
            if (aFormat.getString(MediaFormat.KEY_MIME) != MediaFormat.MIMETYPE_AUDIO_AAC) {
                error("التصدير يدعم تسجيل AAC داخل M4A أو MP4 فقط. حوّل الملف الصوتي إلى M4A/AAC أولًا.")
            }
            video.selectTrack(vIndex)
            audio.selectTrack(aIndex)
            val outputDescriptor = context.contentResolver.openFileDescriptor(outputUri, "rw")
                ?: error("تعذّر فتح ملف الحفظ")
            outputDescriptor.use { descriptor ->
                muxer = MediaMuxer(descriptor.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                val rotation = MediaMetadataRetriever()
                try {
                    rotation.setDataSource(context, videoUri)
                    val degrees = rotation.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
                        ?.toIntOrNull() ?: 0
                    if (degrees in listOf(0, 90, 180, 270)) muxer!!.setOrientationHint(degrees)
                } catch (_: Exception) {
                    // Rotation metadata may be missing; the copy still proceeds.
                } finally { rotation.release() }

                val outVideoTrack = muxer!!.addTrack(vFormat)
                val outAudioTrack = muxer!!.addTrack(aFormat)
                muxer!!.start()
                started = true

                val maxVideoPacket = if (vFormat.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                    vFormat.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)
                } else 0
                val maxAudioPacket = if (aFormat.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                    aFormat.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)
                } else 0
                val buffer = ByteBuffer.allocateDirect(max(16 * 1024 * 1024, max(maxVideoPacket, maxAudioPacket)))
                val info = MediaCodec.BufferInfo()
                val videoFirstTime = max(0L, video.sampleTime)
                val audioFirstTime = max(0L, audio.sampleTime)
                val offsetUs = (offsetSeconds * 1_000_000.0).toLong()
                val videoDurationUs = when {
                    vFormat.containsKey(MediaFormat.KEY_DURATION) -> vFormat.getLong(MediaFormat.KEY_DURATION)
                    else -> Long.MAX_VALUE
                }
                var vHas = video.sampleTime >= 0
                var aHas = audio.sampleTime >= 0
                while (vHas || aHas) {
                    val videoPts = if (vHas) video.sampleTime - videoFirstTime else Long.MAX_VALUE
                    val audioPts = if (aHas) audio.sampleTime - audioFirstTime - offsetUs else Long.MAX_VALUE
                    if (aHas && (audioPts < 0L || (videoDurationUs != Long.MAX_VALUE && audioPts > videoDurationUs))) {
                        aHas = audio.advance() && audio.sampleTime >= 0
                        continue
                    }
                    if (!vHas && (!aHas || videoDurationUs == Long.MAX_VALUE)) break

                    val writeVideo = vHas && (videoPts <= audioPts || !aHas)
                    val extractor = if (writeVideo) video else audio
                    val pts = if (writeVideo) videoPts else audioPts
                    buffer.clear()
                    val size = extractor.readSampleData(buffer, 0)
                    if (size < 0) {
                        if (writeVideo) vHas = false else aHas = false
                        continue
                    }
                    info.set(0, size, max(0L, pts), extractor.sampleFlags)
                    buffer.position(0)
                    buffer.limit(size)
                    muxer!!.writeSampleData(if (writeVideo) outVideoTrack else outAudioTrack, buffer, info)
                    val hasNext = extractor.advance() && extractor.sampleTime >= 0
                    if (writeVideo) vHas = hasNext else aHas = hasNext
                }
                muxer!!.stop()
                started = false
            }
        } finally {
            if (started) try { muxer?.stop() } catch (_: Exception) { }
            try { muxer?.release() } catch (_: Exception) { }
            video.release()
            audio.release()
        }
    }
}
