package com.synccut.app

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Decode to energy envelopes only. No original media leaves the device. */
object AudioAnalyzer {
    private const val SECONDS = 45

    fun envelope(context: Context, uri: Uri): FloatArray {
        val extractor = MediaExtractor()
        var decoder: MediaCodec? = null
        try {
            extractor.setDataSource(context, uri, null)
            val track = (0 until extractor.trackCount).firstOrNull {
                extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: error("الملف لا يحتوي على مسار صوتي يمكن تحليله.")
            extractor.selectTrack(track)
            val format = extractor.getTrackFormat(track)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: error("صيغة صوت غير معروفة")
            decoder = MediaCodec.createDecoderByType(mime)
            decoder.configure(format, null, null, 0)
            decoder.start()
            val length = SECONDS * SyncMatcher.FRAMES_PER_SECOND
            val sumSq = DoubleArray(length)
            val counts = IntArray(length)
            val info = MediaCodec.BufferInfo()
            var sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var pcmEncoding = AudioFormat.ENCODING_PCM_16BIT
            var eosIn = false
            var eosOut = false
            var maxBin = 0
            var cyclesWithoutData = 0
            while (!eosOut) {
                if (!eosIn) {
                    val inputIndex = decoder.dequeueInputBuffer(10000)
                    if (inputIndex >= 0) {
                        val b = decoder.getInputBuffer(inputIndex)!!
                        b.clear()
                        val size = extractor.readSampleData(b, 0)
                        val timeUs = extractor.sampleTime
                        if (size < 0 || timeUs > SECONDS * 1_000_000L) {
                            decoder.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            eosIn = true
                        } else {
                            decoder.queueInputBuffer(inputIndex, 0, size, max(0L, timeUs), 0)
                            extractor.advance()
                        }
                    }
                }
                when (val outputIndex = decoder.dequeueOutputBuffer(info, 10000)) {
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val out = decoder.outputFormat
                        sampleRate = out.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        channels = out.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        pcmEncoding = if (out.containsKey(MediaFormat.KEY_PCM_ENCODING)) {
                            out.getInteger(MediaFormat.KEY_PCM_ENCODING)
                        } else AudioFormat.ENCODING_PCM_16BIT
                    }
                    MediaCodec.INFO_TRY_AGAIN_LATER -> {
                        cyclesWithoutData++
                        if (cyclesWithoutData > 250) error("تعذّر فك ترميز الصوت على هذا الجهاز")
                    }
                    in 0..Int.MAX_VALUE -> {
                        cyclesWithoutData = 0
                        if (info.size > 0) {
                            if (pcmEncoding != AudioFormat.ENCODING_PCM_16BIT &&
                                pcmEncoding != AudioFormat.ENCODING_PCM_FLOAT) {
                                error("صيغة PCM غير مدعومة في الجهاز")
                            }
                            val source = decoder.getOutputBuffer(outputIndex)!!
                            source.order(ByteOrder.LITTLE_ENDIAN)
                            source.position(info.offset)
                            source.limit(info.offset + info.size)
                            val bytesPerSample = if (pcmEncoding == AudioFormat.ENCODING_PCM_FLOAT) 4 else 2
                            val frames = info.size / (bytesPerSample * channels)
                            for (frame in 0 until frames) {
                                var monoSum = 0.0
                                repeat(channels) {
                                    val sample = if (pcmEncoding == AudioFormat.ENCODING_PCM_FLOAT) {
                                        source.float.toDouble()
                                    } else {
                                        source.short.toDouble() / 32768.0
                                    }
                                    monoSum += sample * sample
                                }
                                val timeUs = info.presentationTimeUs + frame.toLong() * 1_000_000L / sampleRate
                                val bin = (timeUs * SyncMatcher.FRAMES_PER_SECOND / 1_000_000L).toInt()
                                if (bin in 0 until length) {
                                    sumSq[bin] += monoSum / channels
                                    counts[bin]++
                                    maxBin = max(maxBin, bin + 1)
                                }
                            }
                        }
                        eosOut = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        decoder.releaseOutputBuffer(outputIndex, false)
                    }
                }
            }
            if (maxBin < 125) error("الملف قصير جدًا للمزامنة (أقل من 2.5 ثانية)")
            return FloatArray(maxBin) { i ->
                if (counts[i] > 0) sqrt(sumSq[i] / counts[i]).toFloat() else 0f
            }
        } finally {
            try { decoder?.stop() } catch (_: Exception) { }
            try { decoder?.release() } catch (_: Exception) { }
            extractor.release()
        }
    }
}
