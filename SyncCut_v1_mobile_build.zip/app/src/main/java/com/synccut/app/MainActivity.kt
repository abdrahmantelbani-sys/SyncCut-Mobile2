package com.synccut.app

import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private var videoUri: Uri? = null
    private var audioUri: Uri? = null
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var pickVideoButton: Button
    private lateinit var pickAudioButton: Button
    private lateinit var analyzeButton: Button
    private lateinit var exportButton: Button
    private lateinit var videoLabel: TextView
    private lateinit var audioLabel: TextView
    private lateinit var status: TextView
    private lateinit var offsetEdit: EditText
    private lateinit var progress: ProgressBar
    private var busy = false

    private val videoPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            holdPermission(uri)
            videoUri = uri
            videoLabel.text = displayName(uri)
            status.text = "تم اختيار الفيديو."
        }
    }
    private val audioPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            holdPermission(uri)
            audioUri = uri
            audioLabel.text = displayName(uri)
            status.text = "تم اختيار الملف الصوتي."
        }
    }
    private val savePicker = registerForActivityResult(ActivityResultContracts.CreateDocument("video/mp4")) { output ->
        val vid = videoUri
        val aud = audioUri
        if (output != null && vid != null && aud != null) {
            val seconds = offsetEdit.text.toString().trim().replace(',', '.').toDoubleOrNull()
            if (seconds == null || !seconds.isFinite()) {
                status.text = "أدخل قيمة رقمية صحيحة للإزاحة بالثواني."
                return@registerForActivityResult
            }
            launchJob("جاري تصدير MP4 على الهاتف…") {
                VideoExporter.export(this, vid, aud, output, seconds)
                "تم حفظ الفيديو بنجاح في المكان الذي اخترته ✅"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        pickVideoButton = findViewById(R.id.pickVideo)
        pickAudioButton = findViewById(R.id.pickAudio)
        analyzeButton = findViewById(R.id.analyze)
        exportButton = findViewById(R.id.export)
        videoLabel = findViewById(R.id.videoName)
        audioLabel = findViewById(R.id.audioName)
        status = findViewById(R.id.status)
        offsetEdit = findViewById(R.id.offset)
        progress = findViewById(R.id.progress)

        savedInstanceState?.let {
            videoUri = it.getString("video")?.let(Uri::parse)
            audioUri = it.getString("audio")?.let(Uri::parse)
            offsetEdit.setText(it.getString("offset", "0.000"))
            videoUri?.let { uri -> videoLabel.text = displayName(uri) }
            audioUri?.let { uri -> audioLabel.text = displayName(uri) }
        }
        pickVideoButton.setOnClickListener { if (!busy) videoPicker.launch(arrayOf("video/*")) }
        pickAudioButton.setOnClickListener { if (!busy) audioPicker.launch(arrayOf("audio/*")) }
        analyzeButton.setOnClickListener {
            val vid = videoUri
            val aud = audioUri
            if (vid == null || aud == null) {
                status.text = "اختَر الفيديو والصوت أولًا."
                return@setOnClickListener
            }
            launchJob("جاري تحليل تطابق الموجات الصوتية (أول 45 ثانية)…") {
                val videoWave = AudioAnalyzer.envelope(this, vid)
                val audioWave = AudioAnalyzer.envelope(this, aud)
                val result = SyncMatcher.find(videoWave, audioWave)
                    ?: error("لم أجد تطابقًا صوتيًا موثوقًا. جرّب إزاحة يدوية أو مقاطع بها نفس الصوت الواضح.")
                runOnUiThread {
                    offsetEdit.setText(String.format(Locale.US, "%.3f", result.seconds))
                }
                "تمت المزامنة ✅ الإزاحة ${String.format(Locale.US, "%.3f", result.seconds)} ثانية، درجة التطابق ${String.format(Locale.US, "%.0f", result.correlation * 100)}٪. راجع النتيجة قبل التصدير."
            }
        }
        exportButton.setOnClickListener {
            if (videoUri == null || audioUri == null) {
                status.text = "اختَر الفيديو والصوت أولًا."
            } else if (!busy) {
                val name = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
                savePicker.launch("SyncCut_$name.mp4")
            }
        }
    }

    private fun launchJob(message: String, job: () -> String) {
        if (busy) return
        busy = true
        progress.visibility = View.VISIBLE
        status.text = message
        listOf(pickVideoButton, pickAudioButton, analyzeButton, exportButton).forEach { it.isEnabled = false }
        worker.execute {
            val result = try { job() } catch (t: Throwable) {
                "تعذّر إكمال العملية: ${t.localizedMessage ?: t.javaClass.simpleName}"
            }
            runOnUiThread {
                busy = false
                progress.visibility = View.GONE
                status.text = result
                listOf(pickVideoButton, pickAudioButton, analyzeButton, exportButton).forEach { it.isEnabled = true }
            }
        }
    }

    private fun holdPermission(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: SecurityException) { }
    }
    private fun displayName(uri: Uri): String {
        return try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c: Cursor ->
                if (c.moveToFirst()) c.getString(0) else null
            } ?: uri.lastPathSegment ?: "ملف محدد"
        } catch (_: Exception) { uri.lastPathSegment ?: "ملف محدد" }
    }
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("video", videoUri?.toString())
        outState.putString("audio", audioUri?.toString())
        outState.putString("offset", offsetEdit.text.toString())
    }
    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) worker.shutdown()
    }
}
