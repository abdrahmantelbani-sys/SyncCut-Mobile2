package com.synccut.app

import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * The video and the external audio must contain the same real-world sound.
 * Positive offset means the external recorder started first.
 * Coarse analysis: 20ms energy frames, lag search up to +/-30 seconds.
 */
object SyncMatcher {
    const val FRAMES_PER_SECOND = 50
    const val MAX_LAG_FRAMES = 30 * FRAMES_PER_SECOND

    data class Match(val seconds: Double, val correlation: Double)

    fun features(rms: FloatArray): FloatArray {
        // Log-energy with a local high-pass filter reduces level and noise-floor differences.
        val logEnergy = DoubleArray(rms.size) { ln(1.0 + 30.0 * max(0.0, rms[it].toDouble())) }
        val sums = DoubleArray(rms.size + 1)
        for (i in logEnergy.indices) sums[i + 1] = sums[i] + logEnergy[i]
        return FloatArray(rms.size) { i ->
            val start = max(0, i - 25)
            val end = min(rms.size, i + 26)
            (logEnergy[i] - (sums[end] - sums[start]) / (end - start)).toFloat()
        }
    }

    fun find(video: FloatArray, external: FloatArray): Match? {
        if (video.size < 125 || external.size < 125) return null
        val v = features(video)
        val a = features(external)
        val minOverlap = min(300, min(v.size, a.size)) // >=2.5 seconds, prefer six seconds
        var bestLag = 0
        var bestScore = -1.0
        val maxLag = min(MAX_LAG_FRAMES, max(v.size, a.size) - minOverlap)
        for (lag in -maxLag..maxLag) {
            // external[videoIndex + lag] corresponds to video[videoIndex].
            val start = max(0, -lag)
            val stop = min(v.size, a.size - lag)
            val n = stop - start
            if (n < minOverlap) continue
            var sumV = 0.0; var sumA = 0.0
            var sumVV = 0.0; var sumAA = 0.0; var sumVA = 0.0
            for (i in start until stop) {
                val x = v[i].toDouble()
                val y = a[i + lag].toDouble()
                sumV += x; sumA += y
                sumVV += x * x; sumAA += y * y; sumVA += x * y
            }
            val varianceV = sumVV - sumV * sumV / n
            val varianceA = sumAA - sumA * sumA / n
            if (varianceV < 0.0001 || varianceA < 0.0001) continue
            val normalized = (sumVA - sumV * sumA / n) / sqrt(varianceV * varianceA)
            // Avoid spuriously excellent matches using only a tiny overlap.
            val score = normalized * min(1.0, sqrt(n / 450.0))
            if (score > bestScore) {
                bestScore = score
                bestLag = lag
            }
        }
        return if (bestScore >= 0.27) Match(bestLag.toDouble() / FRAMES_PER_SECOND, bestScore) else null
    }
}
